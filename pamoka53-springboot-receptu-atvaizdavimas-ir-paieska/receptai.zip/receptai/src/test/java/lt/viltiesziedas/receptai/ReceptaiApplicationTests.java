package lt.viltiesziedas.receptai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceptaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
