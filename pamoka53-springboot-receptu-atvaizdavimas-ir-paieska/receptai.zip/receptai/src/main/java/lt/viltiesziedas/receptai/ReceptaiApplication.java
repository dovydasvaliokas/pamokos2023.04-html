package lt.viltiesziedas.receptai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceptaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceptaiApplication.class, args);
	}

}
